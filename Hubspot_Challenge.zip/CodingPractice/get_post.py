#!/usr/bin/env python

## Thomas Kiley
## Thomas_Kiley1@student.uml.edu
## 9/2/2018

import requests, json

#function for sending our POST request
def post_req(URL, PARAMS):
        #define input parameters for post function
        #URL_POST  = ""
        #PARAMS_POST = {}
        URL_POST = URL
        PARAMS_POST = PARAMS
        #make the post request and capture the return text
        response_post = requests.post(url = URL_POST, data = PARAMS_POST)
        response_text = response_post.json()
        print(response_text)

#Make the Get request
################################################
#define our input parameters for the get function
URL_GET = "https://candidate.hubteam.com/candidateTest/v3/problem/dataset?"
PARAMS_GET = {"userKey":'d2d3990dc17bb5f903fb0199b7d2'}

#make the get request and format the data as json
response_get = requests.get(url = URL_GET, params = PARAMS_GET)
json_get = response_get.json()

#check for valid response
print response_get


#################################################

#Define dictionary to hold solutuion
c_times_dict = {"countries":[]}

#First seperate the data by country, because the dates will differ country to country
countries = {}
for i in json_get['partners']:
	if i['country'] in countries.keys():
		countries[i['country']] = countries[i['country']] + [i]
	else:
		countries[i['country']] = [i]
# walk through the data country by country to find the best dates, and the attendees
for key in countries.keys():
	times = {}
	for entry in countries[key]:
		# get a list of all unique dates and their frequency
		for time in entry['availableDates']:
			if time in times.keys():
				times[time] = times[time] + 1
			else:
				times[time] = 1
	# find the best two consecutive days 
	best_dates = []
	num = 0
	for t in range(len(sorted(times))-1):
		if times[sorted(times)[t]] + times[sorted(times)[t+1]] > num:
			num = times[sorted(times)[t]] + times[sorted(times)[t+1]]
			best_dates = [sorted(times)[t], sorted(times)[t+1]]
	# loop back through the partners to find the list of everyone who can make it
	at_list = []
	for entry in countries[key]:
		if (best_dates[0] in entry['availableDates']) and (best_dates[1] in entry['availableDates']):
			at_list = at_list + [entry['email']]
	# build solution entry
	event_info = {"attendeeCount":len(at_list), "attendees":at_list, "name":key, "startDate":best_dates[0]} 	
	c_times_dict['countries'] = c_times_dict['countries'] + [event_info]
					
# submit solution POST request
post_req("https://candidate.hubteam.com/candidateTest/v3/problem/result?userKey=d2d3990dc17bb5f903fb0199b7d2",json.dumps(c_times_dict)) 
################################################

